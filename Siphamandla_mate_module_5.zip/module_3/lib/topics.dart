import 'dart:html';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/widgets.dart';
import 'package:firebase_core/firebase_core.dart';

class TopicList extends StatefulWidget {
  const TopicList({Key? key}) : super(key: key);

  @override
  State<TopicList> createState() => _TopicListState();
}

class _TopicListState extends State<TopicList> {
  final Stream<QuerySnapshot> _myTopics =
      FirebaseFirestore.instance.collection("Topics").snapshots();

  @override
  Widget build(BuildContext context) {
    TextEditingController _Topic1FieldController = TextEditingController();
    TextEditingController _Topic2FieldController = TextEditingController();
    TextEditingController _Topic3FieldController = TextEditingController();
    void _delete(docId) {
      FirebaseFirestore.instance
          .collection("topics")
          .doc(docId)
          .delete()
          .then((value) => print("deleted"));
    }

    void _update(data) {
      var collection = FirebaseFirestore.instance.collection("Topics");
      _Topic1FieldController.text = data["First_Topic"];
      _Topic2FieldController.text = data["Second_Topic"];
      _Topic3FieldController.text = data["Third_Topic"];

      showDialog(
          context: context,
          builder: (_) => AlertDialog(
                title: Text("Update"),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: _Topic1FieldController,
                    ),
                    TextField(
                      controller: _Topic2FieldController,
                    ),
                    TextField(
                      controller: _Topic3FieldController,
                    ),
                    TextButton(
                        onPressed: () {
                          collection.doc(data["doc_id"]).update({
                            "First_Topic": _Topic1FieldController,
                            "Second_Topic": _Topic2FieldController,
                            "Third_Topic": _Topic3FieldController,
                          });
                          Navigator.pop(context);
                        },
                        child: Text("update"))
                  ],
                ),
              ));
    }

    return StreamBuilder(
      stream: _myTopics,
      builder: (BuildContext context,
          AsyncSnapshot<QuerySnapshot<Object?>> snapshot) {
        if (snapshot.hasError) {
          return Text("Something Went Wrong");
        }
        if (snapshot.connectionState == ConnectionState.waiting) {
          return CircularProgressIndicator();
        }

        if (snapshot.hasData) {
          return Row(
            children: [
              Expanded(
                  child: SizedBox(
                height: (MediaQuery.of(context).size.height),
                width: MediaQuery.of(context).size.width,
                child: ListView(
                  children: snapshot.data!.docs
                      .map((DocumentSnapshot documentSnapshot) {
                    Map<String, dynamic> data =
                        documentSnapshot.data()! as Map<String, dynamic>;
                    return Column(
                      children: [
                        Row(
                          children: [
                            ListTile(
                              title: Text(data['First_Topic']),
                              isThreeLine: true,
                              subtitle: Text(data['Second_Topic']),
                              leading: Icon(Icons.label),
                              trailing: Text(data["Third_Topic"]),
                            ),
                            ButtonTheme(
                                child: ButtonBar(
                              children: [
                                OutlinedButton.icon(
                                  onPressed: () {
                                    _update(data);
                                  },
                                  icon: Icon(Icons.edit),
                                  label: Text("edit"),
                                ),
                                OutlinedButton.icon(
                                  onPressed: () {
                                    _delete(data["doc_id"]);
                                  },
                                  icon: Icon(Icons.remove),
                                  label: Text("delete"),
                                )
                              ],
                            ))
                          ],
                        ),
                      ],
                    );
                  }).toList(),
                ),
              ))
            ],
          );
        } else {
          return (Text("No data"));
        }
      },
    );
  }
}
