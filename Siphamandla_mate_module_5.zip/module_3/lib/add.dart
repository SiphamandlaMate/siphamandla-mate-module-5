import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/topics.dart';

class Addsession extends StatelessWidget {
  const Addsession({Key? key}) : super(key: key);
  static const String _title = 'Add Topics';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _title,
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: Colors.lightBlue[800],
        fontFamily: 'Georgia',
        textTheme: const TextTheme(
          headline1: TextStyle(fontSize: 8, fontWeight: FontWeight.bold),
          headline6: TextStyle(fontSize: 8, fontStyle: FontStyle.italic),
          bodyText2: TextStyle(fontSize: 8, fontFamily: 'Hind'),
        ),
      ),
      home: Scaffold(
        appBar: AppBar(title: const Text(_title)),
        body: const MyStatefulWidget(),
      ),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyStatefulWidget extends StatefulWidget {
  const MyStatefulWidget({Key? key}) : super(key: key);

  @override
  State<MyStatefulWidget> createState() => _MyStatefulWidgetState();
}

class _MyStatefulWidgetState extends State<MyStatefulWidget> {
  @override
  Widget build(BuildContext context) {
    TextEditingController Topic1Controller = TextEditingController();
    TextEditingController Topic2Controller = TextEditingController();
    TextEditingController Topic3Controller = TextEditingController();

    Future _addsessions() {
      final topic1 = Topic1Controller.text;
      final topic2 = Topic2Controller.text;
      final topic3 = Topic3Controller.text;

      final ref = FirebaseFirestore.instance.collection("Topics").doc();

      return ref
          .set({
            "First_Topic": topic1,
            "Second_Topic": topic2,
            "Third_Topic": topic3,
            "doc_id": ref.id
          })
          .then((value) => {
                Topic1Controller.text = "",
                Topic2Controller.text = "",
                Topic3Controller.text = ""
              })
          .catchError((onError) => log(onError));
    }

    return Scaffold(
        body: Center(
            child: SingleChildScrollView(
                child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Column(
          children: [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              child: TextField(
                  controller: Topic1Controller,
                  decoration: InputDecoration(
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular((20))),
                      hintText: "Enter 1st Topic")),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              child: TextField(
                  controller: Topic2Controller,
                  decoration: InputDecoration(
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular((20))),
                      hintText: "Enter 2nd Topic")),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              child: TextField(
                  controller: Topic3Controller,
                  decoration: InputDecoration(
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular((20))),
                      hintText: "Enter 3rd Topic")),
            ),
            ElevatedButton(
                onPressed: () {
                  _addsessions();
                },
                child: Text("Ädd Topics"))
          ],
        ),
        TopicList(),
      ],
    ))));
  }
}
